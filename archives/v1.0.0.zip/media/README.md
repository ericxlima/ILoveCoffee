# Imagens

## Menu
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/menu.PNG" /></p>

## Jogo da Forca
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/jogo_da_forca.PNG" /></p>

## Máquina de Café
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/maquina.PNG" /></p>

## Mercado
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/mercado.PNG" /></p>
  
## Instruções
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/descricoes.PNG" /></p>
  
## Pedra Papel Tesoura
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/pedra_papel_tesoura.PNG" /></p>

## Jogo da Velha
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/jogo_da_velha.PNG" /></p>

## Banco
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/banco.PNG" /></p>

## Ranking
<p align="center">
  <img src="https://github.com/ericxlima/ILoveCoffee/blob/master/media/ranking.PNG" /></p>